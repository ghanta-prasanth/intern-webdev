
const form=document.getElementById('searchForm');
const cityInput=document.getElementById('cityInput');
const weatherBox=document.getElementById('weather');
const message=document.getElementById('message');

async function getWeather(city){
  try{
    message.textContent='Loading...';
    weatherBox.innerHTML='';

    const geo=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`);
    if(!geo.ok) throw new Error('Location request failed');
    const geoData=await geo.json();

    if(!geoData.results?.length) throw new Error('City not found');

    const {latitude,longitude,name,country}=geoData.results[0];

    const weatherRes=await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m`
    );
    if(!weatherRes.ok) throw new Error('Weather request failed');

    const data=await weatherRes.json();
    const current=data.current;

    weatherBox.innerHTML=`
      <h2>${name}, ${country}</h2>
      <p><strong>Temperature:</strong> ${current.temperature_2m}°C</p>
      <p><strong>Humidity:</strong> ${current.relative_humidity_2m}%</p>
      <p><strong>Wind Speed:</strong> ${current.wind_speed_10m} km/h</p>
    `;
    message.textContent='';
  }catch(err){
    message.textContent=err.message;
  }
}

form.addEventListener('submit',e=>{
  e.preventDefault();
  getWeather(cityInput.value.trim());
});
