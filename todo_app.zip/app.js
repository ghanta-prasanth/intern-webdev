
const form=document.getElementById('taskForm');
const input=document.getElementById('taskInput');
const list=document.getElementById('taskList');
let filter='all';
let tasks=JSON.parse(localStorage.getItem('tasks')||'[]');

function save(){localStorage.setItem('tasks',JSON.stringify(tasks));}
function render(){
 list.innerHTML='';
 tasks.filter(t=>filter==='all'||(filter==='active'&&!t.done)||(filter==='completed'&&t.done))
 .forEach(t=>{
   const li=document.createElement('li');
   li.className=t.done?'completed':'';
   li.innerHTML=`<input type="checkbox" ${t.done?'checked':''}>
   <span>${t.text}</span>
   <button class="edit">Edit</button>
   <button class="delete">Delete</button>`;
   li.dataset.id=t.id;
   list.appendChild(li);
 });
}
form.addEventListener('submit',e=>{
 e.preventDefault();
 tasks.push({id:Date.now(),text:input.value,done:false});
 input.value=''; save(); render();
});
document.addEventListener('click',e=>{
 const li=e.target.closest('li'); if(!li) return;
 const id=Number(li.dataset.id);
 const task=tasks.find(t=>t.id===id);
 if(e.target.matches('.delete')) tasks=tasks.filter(t=>t.id!==id);
 if(e.target.matches('.edit')){
   const v=prompt('Edit task',task.text);
   if(v) task.text=v;
 }
 if(e.target.matches('input[type=checkbox]')) task.done=e.target.checked;
 save(); render();
});
document.querySelector('.filters').addEventListener('click',e=>{
 if(e.target.dataset.filter){filter=e.target.dataset.filter; render();}
});
render();
