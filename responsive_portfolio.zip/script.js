
const btn=document.getElementById('themeToggle');
btn.addEventListener('click',()=>{
  const dark=document.body.getAttribute('data-theme')==='dark';
  document.body.setAttribute('data-theme', dark ? 'light' : 'dark');
});
