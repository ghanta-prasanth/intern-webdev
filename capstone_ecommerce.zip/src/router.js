
const app=document.getElementById('app');
const routes={
'/':'<h2>Home</h2><p>Production-ready SPA architecture.</p>',
'/products':'<h2>Products</h2><div id="products"></div>',
'/about':'<h2>About</h2><p>Capstone project.</p>'
};
export function router(){
 const path=location.hash.slice(1)||'/';
 app.innerHTML=routes[path]||'<h2>404</h2>';
 if(path==='/products'){
   document.getElementById('products').innerHTML=''' +
   ['Laptop','Phone','Headphones'].map(p=>`<article><h3>${p}</h3></article>`).join('');
 }
}
